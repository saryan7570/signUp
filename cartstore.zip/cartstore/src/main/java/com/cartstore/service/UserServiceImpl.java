package com.cartstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartstore.bean.User;
import com.cartstore.dao.UserDao;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	UserDao userDao;
	@Override
	public List<User> getAllUsers() {
	
		return userDao.findAll();
	}

	@Override
	public List<User> createUser(User user) {
		
		  userDao.save(user);
	        return userDao.findAll();
	}

}
