import { Injectable } from '@angular/core';
import { SignUp } from './signup';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StoreService {
arr:SignUp[]=[];
  httpClient: HttpClient;
  constructor(httpClient : HttpClient) {
    this.httpClient = httpClient;
   }


   public create(user) {
    return this.httpClient.post<SignUp>("http://localhost:8093/create", user);
    }
}
