export class SignUp {
    
    fname: String;
    lname: String;
    mobileNo: String;
    emailId: String;
    gender: String;
    password: String;
    constructor(fname: String, lname: String, emailId: String, gender: String, password: String, mobileNo: String) {
      
        this.fname = fname;
        this.mobileNo = mobileNo;
        this.lname = lname;
        this.emailId = emailId;
        this.gender = gender;
        this.password = password;

    }
}